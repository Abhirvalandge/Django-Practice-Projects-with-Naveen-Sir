default_app_config = 'django.contrib.admindocs.apps.AdminDocsConfig'
